

import 'package:flutter/cupertino.dart';

import 'Widget/PhotoOCR.dart';

class ScanPhotoPage extends StatelessWidget {
  const ScanPhotoPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const PhotoOCR();
  }
}
