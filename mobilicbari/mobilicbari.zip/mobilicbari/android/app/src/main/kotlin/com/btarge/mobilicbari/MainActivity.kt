package com.btarge.mobilicbari

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
